import os
from sb3_contrib import TQC

class Agent:
    def __init__(self, model_dir: str):
        self.model = TQC.load(os.path.join(model_dir, "sac_model.zip"))

    def act(self, observation):
        action, _ = self.model.predict(observation, deterministic=True)
        return action
